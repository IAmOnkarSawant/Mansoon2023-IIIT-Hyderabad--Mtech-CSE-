import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Router, Routes } from 'react-router-dom';
import ReactElement from './Components/ReactElement';
import Component1 from './Components/Component1';
import Component2 from './Components/Component2';
import CompProps from './Components/CompProps';
import CompStates from './Components/CompStates';
import Login from './Components/Login';
import Register from './Components/Register';
import Home from './Components/Home';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
        <Route path='/' element={
            <div>
              <Home />
            </div>
          } />
          <Route path='/element' element={
            <div>
              <ReactElement />
            </div>
          } />

          <Route path='/component' element={
            <div>
              <Component1 />
              <Component2 />
            </div>
          } />

          <Route path='/prop' element={
            <div>
              <CompProps name="Priyanshu" />

            </div>
          } />

          <Route path='/states' element={
            <div>
              <CompStates />
            </div>
          } />

          <Route path='/login' element={
            <div>
              <Login />
            </div>
          } />

          <Route path='/register' element={
            <div>
              <Register />
            </div>
          } />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
