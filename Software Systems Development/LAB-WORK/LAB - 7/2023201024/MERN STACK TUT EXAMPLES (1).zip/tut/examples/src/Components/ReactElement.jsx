import React from 'react'
import ReactDOM from 'react-dom';


const ReactElement = () => {

    const element = <h1>ReactElement</h1>;

    
    const root = ReactDOM.createRoot(
        document.getElementById('root')

    );

    root.render(element);
  return (
    <div id='root'>hi</div>
  )
}

export default ReactElement