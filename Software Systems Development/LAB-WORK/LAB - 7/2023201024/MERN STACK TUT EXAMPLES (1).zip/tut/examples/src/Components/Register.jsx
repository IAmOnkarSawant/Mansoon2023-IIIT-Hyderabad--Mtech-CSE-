import React, { useState } from 'react'
const BACKEND_URI = "http://localhost:3002/auth/";

const Register = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");


    return (
        <div className=" register-form">
            <br />
            <br />
            <br />
            <br />
            <form className='inputs'>
                <input type='email' placeholder='Email' className='form-control username' value={email} onChange={(e) => setEmail(e.target.value)} required />
                <input type='password' placeholder='Password' className='form-control password' value={password} onChange={(e) => setPassword(e.target.value)} required />
            </form>
            <br />
            <br />

            <div className='inputs1'>
                <button type='submit' className='form-control registerSubmitBtn ' onClick={async (e) => {
                    // send fetch (POST) request to server
                    const requestOptions = {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        mode: 'cors',
                        body: JSON.stringify({ email: email, password: password })
                    };
                    setEmail("");
                    setPassword("");
                    var res = await fetch(BACKEND_URI + "register", requestOptions);
                    // console.log(res);
                    alert((await res.json())["message"]);

                }}> Register </button>
            </div>
            <p className='forgotpasswordlink'>Already Have a Account? <a href='/login'>Login</a></p>


        </div>
    );
}

export default Register