import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

const BACKEND_URI = "http://localhost:3002/auth/";


const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();
    const navigateToHome = () => {
        navigate('/states');
    }


    return (
        <div className=" login-form">
            <br />
            <br />
            <br />
            <br />
            <br />
            <form className='inputs'>
                <input type='text' placeholder='Username' className='form-control username' value={email} onChange={(e) => setEmail(e.target.value)} required />
                <input type='password' placeholder='Password' className='form-control password' value={password} onChange={(e) => setPassword(e.target.value)} required />
                <br /> <br />
                {/* <p className='forgotpasswordlink'>Forgot Password? <a href='/forgotPassword'>Click Here</a></p> */}
            </form>
            <div className='inputs1'>
                <button type='submit' className='form-control submitBtn' onClick={async (e) => {
                    // send fetch (POST) request to server
                    const requestOptions = {
                        // credentials: 'include',
                        method: 'POST',
                        mode: 'cors',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ email: email, password: password })
                    };

                    var res = await fetch(BACKEND_URI + "login", requestOptions);
                    console.log(res.json) 
                    setEmail("");
                    setPassword("");
                    alert((await res.json())["message"]);
                    
                    if (res.status === 200) {
                        // sessionStorage.setItem("curr_email", email);
                        navigateToHome();
                    }
                }}> Login </button>
            </div>
            <p className='forgotpasswordlink'>Not Having a Account? <a href='/register'>Create now</a></p>

        </div>
    );
}

export default Login