import React, { useState } from 'react'

const CompStates = () => {

    const [name, setName] = useState("Priyanshu");
    return (
        <div>
            <h2>Hello, {name}</h2> <br/> <br/> <br/>
            <button onClick={(e) => setName("Krati")} >Change Name</button>
        </div>
    )
}

export default CompStates