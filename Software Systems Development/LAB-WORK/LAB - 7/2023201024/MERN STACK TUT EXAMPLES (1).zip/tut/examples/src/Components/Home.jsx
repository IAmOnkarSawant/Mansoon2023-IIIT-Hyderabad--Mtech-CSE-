import React from 'react'

const Home = () => {
  return (
    <div>
        <center>
            <h1 style={{display:"flex", flexDirection:"column", justifyContent:"center", marginTop:"20%"}}>Welcome to Mern Stack Tutorial</h1>
        </center>
    </div>
  )
}

export default Home