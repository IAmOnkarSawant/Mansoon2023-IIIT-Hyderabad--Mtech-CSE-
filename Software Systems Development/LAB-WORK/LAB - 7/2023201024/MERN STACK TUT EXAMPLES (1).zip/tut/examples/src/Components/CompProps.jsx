import React from 'react'

const CompProps = (props) => {
  return (
    <div>Hello, {props.name}</div>
  )
}

export default CompProps