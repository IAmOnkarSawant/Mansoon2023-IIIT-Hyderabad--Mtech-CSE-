import React from 'react'

const Component2 = () => {
  return (
    <div>Component2</div>
  )
}

export default Component2